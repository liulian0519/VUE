export const setIsAuthenticated = (state,data)=>{
  state.isAuthenticated = data;
}
