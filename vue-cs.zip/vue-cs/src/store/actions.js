export const setIsAuthenticated = ({commit},data)=>{
  commit("setIsAuthenticated",data);
}
