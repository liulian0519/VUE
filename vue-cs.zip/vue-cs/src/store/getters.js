export const isAuthenticated = state=>state.isAuthenticated;
